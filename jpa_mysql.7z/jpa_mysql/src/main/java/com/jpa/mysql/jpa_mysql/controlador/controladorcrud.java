package com.jpa.mysql.jpa_mysql.controlador;

import com.jpa.mysql.jpa_mysql.modelo.usuarios;
import com.jpa.mysql.jpa_mysql.modelo.usuarioscrud;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/crudusuario")
public class controladorcrud {
    
    @Autowired
    private usuarioscrud userRepository;

    @GetMapping("/all")
    @ResponseBody
    public Iterable<usuarios> allUsers(){
        return userRepository.findAll();
    }
    
    @GetMapping("/usuarioxid")
    @ResponseBody
    public usuarios oneUsers(@RequestParam int idusuario){
        return userRepository.findById(idusuario);
    }

    @PostMapping("/add")
    @ResponseBody
    public String addNewUser(@RequestParam String usuario,
    @RequestParam String password,
    @RequestParam String email){
        usuarios usu=new usuarios();
        usu.setUsuario(usuario);
        usu.setPassword(password);
        usu.setEmail(email);
        userRepository.save(usu);
        return "Usuario agregado!!!";
    }

   // @PostMapping("/delete")
    @DeleteMapping("/delete")
    @ResponseBody
    public String deleteUser(@RequestParam int idusuario){
        userRepository.deleteById(idusuario);
        return "Usuario eliminado!!!";
    }

   // @PostMapping("/update")
    @PutMapping("/update")
    @ResponseBody
    public String updateUser(@RequestParam int idusuario,
    @RequestParam String usuario,
    @RequestParam String password,
    @RequestParam String email){
        usuarios usu=this.userRepository.findById(idusuario);
        usu.setUsuario(usuario);
        usu.setPassword(password);
        usu.setEmail(email);
        userRepository.save(usu);
        return "Usuario modificado!!!";
    }
}
