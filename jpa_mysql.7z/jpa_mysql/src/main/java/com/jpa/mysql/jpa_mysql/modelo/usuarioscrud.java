package com.jpa.mysql.jpa_mysql.modelo;

import org.springframework.data.repository.CrudRepository;

public interface usuarioscrud extends CrudRepository<usuarios, Integer> 
{
  usuarios findById(int id);
}
