import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor(private http:HttpClient) { 
    console.log("El HTTP disponible");
  }

  ListarUsuarios(): any {
    return this.http.get("http://localhost:8080/crudusuario/all");
  }
}
