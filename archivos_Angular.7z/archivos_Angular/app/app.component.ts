import { Component, OnInit } from '@angular/core';
import { UsersService } from './services/users.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'appsabado16';
  lsUsuarios: any=[];

  constructor(private usuServicio:UsersService){
    console.log("Componente creado");
  }

  ngOnInit(): void {
      console.log("Componente iniciado");
      this.usuServicio.ListarUsuarios().subscribe(
        (e:any) => this.lsUsuarios=e
      );
  }
}
