export class Usuarios {
    
    idusuario?: number = 0;
    usuario: string = "";
    password: string = "";
    email: string = "";
 
    public constructor(usuario: string, password: string, email: string)
    {
        this.usuario=usuario;
        this.password=password;
        this.email=email;
    }
}
