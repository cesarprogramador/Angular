import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';

import { CommonModule } from '@angular/common'; 
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; 
import { ToastrModule } from 'ngx-toastr';
import { ListarUsuariosComponent } from './usuarios/listar-usuarios.component';
import { DetalleUsuarioComponent } from './usuarios/detalle-usuario.component';
import { NuevoUsuarioComponent } from './usuarios/nuevo-usuario.component';
import { EditarUsuarioComponent } from './usuarios/editar-usuario.component';

//cliente http
import { HttpClientModule } from '@angular/common/http';
//Formulario
import { FormsModule } from '@angular/forms';

//Routing
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [
    AppComponent,
    ListarUsuariosComponent,
    DetalleUsuarioComponent,
    NuevoUsuarioComponent,
    EditarUsuarioComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    BrowserAnimationsModule, // required animations module 
	  ToastrModule.forRoot(), // ToastrModule added 

    RouterModule.forRoot([
      //archivo raiz y lista todos los usuarios
      {path:'listar', component: ListarUsuariosComponent},
      //Permite ver un usuario seleccionado
      {path:'detalle/:id', component:DetalleUsuarioComponent},
      //Abre formularoi que permite dar de alta un usuario
      {path:'nuevo', component:NuevoUsuarioComponent},
      //Permite editar un usuario para modificar datos
      {path:'editar/:id',component:EditarUsuarioComponent},
      //Permite redirecionar a la ruta raiz por cualquier error y siempre debe de ir al final
      {path:'**',redirectTo:'/listar',pathMatch:'full'}
    ]),

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
