import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Usuarios } from '../models/usuarios';


@Injectable({
  providedIn: 'root'
})
export class UsuarioService {
  private url: string="http://localhost:8080/crudusuario/";

  constructor(private http:HttpClient ) { }

  //Obtiene listado de usuarios
  public getAllUsers():Observable<Usuarios[]>{
    return this.http.get<Usuarios[]>(this.url+"all");
  }

  //Obtiene un usuario seleccionado
  public getUserDetailxId(id: number):Observable<Usuarios>{
    return this.http.get<Usuarios>(this.url+"selectusuarioxid?id="+id);
  }

  //Obtiene un usuario seleccionado
  public getUserDetailxName(nombreusu: string):Observable<Usuarios>{
    return this.http.get<Usuarios>(this.url+`usuarioxnombre/${nombreusu}`);
  }

  //Crea un usuario
  public createUser(usu:Usuarios):Observable<any>{
    console.log(usu);

    return this.http.post<any>(this.url+"addusu", usu);
  }

  //Actualizo un estudiante seleccionado
  public update(usu: Usuarios):Observable<any>{
    return this.http.put<any>(this.url+"updateusu",usu);
    //return this.http.put<any>(this.url+`update/${id}`,usu);
  }

  //Elimino un estudiante seleccionado
  public delete(id: number):Observable<any>{
    console.log (id);

    return this.http.delete<any>(this.url+"deleteusu?id="+id);
  }
}
