import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Usuarios } from '../models/usuarios';
import { UsuarioService } from '../service/usuario.service';

@Component({
  selector: 'app-listar-usuarios',
  templateUrl: './listar-usuarios.component.html',
  styleUrls: ['./listar-usuarios.component.css']
})
export class ListarUsuariosComponent implements OnInit {

  lsUsuarios:Usuarios[]=[];

  constructor(
    private usuarioService: UsuarioService,
    private toastr: ToastrService
    ) { }

  ngOnInit(): void {
    this.CargarUsuario();
  }

  CargarUsuario(): void {
    this.usuarioService.getAllUsers().subscribe(
      data=> {
        this.lsUsuarios= data;
      },
      err => {
        console.log(err);
      }
    );
  }

  EliminarUsuario(id:any){
    this.usuarioService.delete(id).subscribe(
      data=>{
        this.toastr.success('Usuario eliminado', 'Ok!', {
          timeOut: 3000,
        });

        this.CargarUsuario();
      },
      err => {
        this.toastr.error('Usuario no fue eliminado', 'Fail!', {
          timeOut: 3000,
        });
      }
    );
  }

}
