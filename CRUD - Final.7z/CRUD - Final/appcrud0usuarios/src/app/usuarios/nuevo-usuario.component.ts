import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Usuarios } from '../models/usuarios';
import { UsuarioService } from '../service/usuario.service';

@Component({
  selector: 'app-nuevo-usuario',
  templateUrl: './nuevo-usuario.component.html',
  styleUrls: ['./nuevo-usuario.component.css']
})
export class NuevoUsuarioComponent implements OnInit {

  _usuario:string="";
  _password:string="";
  _email:string="";

  constructor(private usuarioService: UsuarioService,
    private toastr: ToastrService,
    private router: Router) { }

  ngOnInit(): void {
  }

  onCreate(): void {
    const vcusuario=new Usuarios(this._usuario,this._password,this._email);
    this.usuarioService.createUser(vcusuario).subscribe(
      data=>{
        this.toastr.success('Usuario creado', 'Ok!', {
          timeOut: 3000,
        });

        this.router.navigate(['/']);
      },
      err => {
        this.toastr.error('Usuario no fue creado', 'Fail!', {
          timeOut: 3000,
        });

        this.router.navigate(['/']);
      }
    );
  }
}