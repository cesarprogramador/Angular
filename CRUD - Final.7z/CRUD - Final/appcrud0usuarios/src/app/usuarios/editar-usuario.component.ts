import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Usuarios } from '../models/usuarios';
import { UsuarioService } from '../service/usuario.service';

@Component({
  selector: 'app-editar-usuario',
  templateUrl: './editar-usuario.component.html',
  styleUrls: ['./editar-usuario.component.css']
})
export class EditarUsuarioComponent implements OnInit {

  _usuario: Usuarios=new Usuarios("","","");

  constructor(private usuarioService: UsuarioService,
    private actRouter:ActivatedRoute,
    private toastr: ToastrService,
    private router: Router) { }

  ngOnInit(): void {
    const id=this.actRouter.snapshot.params['id'];

    console.log(id);
    
    this.usuarioService.getUserDetailxId(id).subscribe(
      data=>{
        this._usuario=data;
       },
      err => {
        this.toastr.error(err.error.mesaje, 'Fail!', {
          timeOut: 3000,
        });

        this.router.navigate(['/']);
      }
      );
  }

  onUpdate(): void {
    const id=this.actRouter.snapshot.params['id'];
    this.usuarioService.update(this._usuario).subscribe(
      data=>{
        this.toastr.success('Usuario modificado', 'Ok!', {
          timeOut: 3000,
        });

        this.router.navigate(['/']);
      },
      err => {
        this.toastr.error('Usuario no fue modificado', 'Fail!', {
          timeOut: 3000,
        });

        this.router.navigate(['/']);
      }
    );
  }
}