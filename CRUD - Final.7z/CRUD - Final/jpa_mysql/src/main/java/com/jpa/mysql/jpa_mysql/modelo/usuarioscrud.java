package com.jpa.mysql.jpa_mysql.modelo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface usuarioscrud extends CrudRepository<usuarios, Integer> 
{
  usuarios findById(int id);

  @Query(value ="SELECT idusuario,usuario,password,email,eliminado FROM usuarios WHERE eliminado=false", nativeQuery=true)
  Iterable<usuarios> allUsers();

  @Query(value ="SELECT count(idusuario) FROM usuarios WHERE usuario=:usunombre", nativeQuery=true)
  int exiteUsuarioxNombre(String usunombre);

  @Query(value ="SELECT count(idusuario) FROM usuarios WHERE usuario=:usunombre AND password=:usupassword", nativeQuery=true)
  int exiteUsuarioxNombrexPasword(String usunombre, String usupassword);
}
